<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class groupMenu extends Model
{
    //
}
