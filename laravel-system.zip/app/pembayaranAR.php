<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class pembayaranAR extends Model
{
    protected $table = 'pembayaran_ar';
}
