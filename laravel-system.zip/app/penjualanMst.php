<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class penjualanMst extends Model
{
    protected $table = 'penjualan_mst';
}
