<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AjuFakturValidasi extends Model
{
    protected $table = 'aju_faktur_validasi';
}
