<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class penjualanTrn extends Model
{
    protected $table = 'penjualan_trn';
}
