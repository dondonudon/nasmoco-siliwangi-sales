<?php

namespace App\Http\Controllers;

use App\msUser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DashboardMaster extends Controller
{

}
