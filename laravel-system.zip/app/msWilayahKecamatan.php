<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class msWilayahKecamatan extends Model
{
    //
}
