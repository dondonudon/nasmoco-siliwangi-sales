<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class msPermission extends Model
{
    protected $table = 'ms_permission';
}
