<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Session;

class sysMenu extends Model
{
    protected $table = 'sys_menu';
}
