<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class msTipeAkun extends Model
{
    //
}
