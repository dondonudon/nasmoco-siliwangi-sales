<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class msLeasing extends Model
{
    //
}
