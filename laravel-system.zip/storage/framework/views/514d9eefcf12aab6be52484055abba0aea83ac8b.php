<?php
    $sidebar = App\Http\Controllers\Dashboard::getAllSidebar();
    $area = App\Http\Controllers\MasterArea::getListArea();
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Nasmoco Siliwangi - Register Account</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="<?php echo e(asset('css/sb-admin-2.min.css')); ?>" rel="stylesheet">

</head>

<body class="bg-gradient-primary">

<div class="container">

    <div class="card o-hidden border-0 shadow-lg my-5">
        <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">

                <div class="col-lg-12">
                    <div class="p-5">
                        <div class="text-center">
                            <h1 class="h4 text-gray-900 mb-4">Buat akun baru</h1>
                        </div>
                        <form class="user">
                            <div class="form-group">
                                <input type="text" class="form-control" id="inputUsername" placeholder="Masukkan username yang anda inginkan" autocomplete="off">
                                <small id="inputUsername" class="form-text text-muted">Username ini akan digunakan untuk login.</small>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="inputEmail" placeholder="Email" autocomplete="off">
                            </div>
                            <div class="form-group row">
                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <input type="password" class="form-control" id="inputPassword" placeholder="Password">
                                </div>
                                <div class="col-sm-6">
                                    <input type="password" class="form-control" id="inputRepeatPassword" placeholder="Repeat Password">
                                </div>
                            </div>

                            <hr style="border-width: 10px">
                            <p><strong>Menu Permission</strong></p>
                            <?php $__currentLoopData = $sidebar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-group row">
                                    <div class="col-sm-2"><?php echo e($s['group']['nama']); ?></div>
                                    <div class="col-sm-10">
                                        <div class="row">
                                            <?php $__currentLoopData = $s['menu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-sm-4">
                                                    <div class="form-check">
                                                        <?php if(in_array($m['id'],['9','8'])): ?>
                                                            <input class="form-check-input" type="checkbox" id="permission_<?php echo e($m['id']); ?>" name="menu_permission[]" value="<?php echo e($m['id']); ?>" checked>
                                                        <?php else: ?>
                                                            <input class="form-check-input" type="checkbox" id="permission_<?php echo e($m['id']); ?>" name="menu_permission[]" value="<?php echo e($m['id']); ?>">
                                                        <?php endif; ?>
                                                            <label class="form-check-label" for="permission_<?php echo e($m['id']); ?>"><?php echo e($m['nama']); ?></label>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                                <hr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <hr style="border-width: 10px">
                            <div class="form-group row">
                                <div class="col-sm-2">Pilih Area</div>
                                <div class="col-sm-10">
                                    <div class="row">
                                        <?php $__currentLoopData = $area; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-sm-4">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" id="area_<?php echo e($a->id); ?>" name="area_permission[]" value="<?php echo e($a->id); ?>">
                                                    <label class="form-check-label" for="area_<?php echo e($a->id); ?>"><?php echo e($a->nama); ?></label>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>

                            <hr style="border-width: 10px">
                            <button type="submit" class="btn btn-primary btn-block">Daftarkan Akun</button>
                            <small id="emailHelp" class="form-text text-muted">
                                Perhatian: <strong>Admin memiliki kewenangan untuk merubah Menu Permission dan Area Permission yang dapat anda akses!</strong>
                                <br>
                                <strong>Untuk mempercepat proses pendaftaran, silahkan check Menu Permission dan Area Permission yang sesuai dengan kebutuhan anda.</strong>
                            </small>
                            <hr style="border-width: 10px">







                        </form>




                        <div class="text-center">
                            <a class="small" href="<?php echo e(url('dashboard/login')); ?>">Anda ingin login?</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<!-- Bootstrap core JavaScript-->
<script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/bootstrap-4.3.1-dist/js/bootstrap.bundle.min.js')); ?>"></script>

<!-- Core plugin JavaScript-->
<script src="<?php echo e(asset('vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

<!-- Custom scripts for all pages-->
<script src="<?php echo e(asset('js/sb-admin-2.min.js')); ?>"></script>

</body>

</html>
<?php /**PATH /home/kevin/Development/nasmoco-siliwangi/resources/views/dashboard-register.blade.php ENDPATH**/ ?>