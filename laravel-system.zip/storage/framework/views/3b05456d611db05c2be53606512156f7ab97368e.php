<?php
$infoArea = App\Http\Controllers\OverviewCard::infoDashboard();
?>

<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
    </div>

    <div class="row">
        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">SPK Bulan Ini</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($infoArea['spk']); ?></div>
                        </div>
                        <div class="col-auto" id="cobaIcon">

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Content Row -->
    <div class="row">

        <?php $__currentLoopData = $infoArea['info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-s font-weight-bold text-primary text-uppercase mb-1"><?php echo e($i); ?></div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($v['x']); ?></div>
                            </div>
                            <div class="col-auto">

                                <form id="viewSPK">
                                    <input type="hidden" name="area" value="<?php echo e($v['id']); ?>">
                                    <button type="button" class="btn btn-primary btn-sm" disabled>Lihat</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <!-- Content Row -->

</div>
<div class="modal fade" id="ModalInfoUpload" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalScrollableTitle">No SPK</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row" id="ModalInfoData"></div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $('#cobaIcon').html('<i class="fas fa-car fa-2x text-gray-300"></i>');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kevin/Development/nasmoco-siliwangi/resources/views/dashboard-overview.blade.php ENDPATH**/ ?>